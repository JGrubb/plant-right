require 'test_helper'

class QuizHelperTest < ActionView::TestCase
end
